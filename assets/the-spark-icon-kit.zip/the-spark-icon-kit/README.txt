The Spark – Universal Symbol for Generative AI

From one human spark, infinite creation.  
Website: https://sparksymbol.org  
GitHub: https://github.com/lara9taylor/spark-symbol

License:  
This symbol is released under the Creative Commons Zero (CC0) license.  
You are free to use, modify, and distribute it without restriction.

—

Created by Lara Taylor  
Design Steward of The Spark  
lara@sparksymbol.org

While attribution is not required, acknowledging Lara’s original design work is always appreciated.
